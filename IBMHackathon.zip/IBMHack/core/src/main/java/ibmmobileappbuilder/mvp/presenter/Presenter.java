package ibmmobileappbuilder.mvp.presenter;

public interface Presenter {
    void startPresenting();
    void stopPresenting();
}
