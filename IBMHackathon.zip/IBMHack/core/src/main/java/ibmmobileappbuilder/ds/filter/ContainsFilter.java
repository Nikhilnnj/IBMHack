package ibmmobileappbuilder.ds.filter;

public interface ContainsFilter extends Filter<String> {
    String getValue();
}
