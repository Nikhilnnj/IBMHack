
package com.ibm.mobileappbuilder.ibmhack20161001050402.presenters;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class GovernmentPlansPresenter extends BasePresenter implements ListCrudPresenter<GovernmentPlansDSItem>,
      Datasource.Listener<GovernmentPlansDSItem>{

    private final CrudDatasource<GovernmentPlansDSItem> crudDatasource;
    private final CrudListView<GovernmentPlansDSItem> view;

    public GovernmentPlansPresenter(CrudDatasource<GovernmentPlansDSItem> crudDatasource,
                                         CrudListView<GovernmentPlansDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(GovernmentPlansDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<GovernmentPlansDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(GovernmentPlansDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(GovernmentPlansDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(GovernmentPlansDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

