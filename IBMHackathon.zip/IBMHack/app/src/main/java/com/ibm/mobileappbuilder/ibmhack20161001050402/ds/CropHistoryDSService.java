
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "CropHistoryDSService" REST Service implementation
 */
public class CropHistoryDSService extends RestService<CropHistoryDSServiceRest>{

    public static CropHistoryDSService getInstance(){
          return new CropHistoryDSService();
    }

    private CropHistoryDSService() {
        super(CropHistoryDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "i0JS1Gqy";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef44d19d17e00300d4c370",
                path,
                "apikey=i0JS1Gqy");
    }

}

