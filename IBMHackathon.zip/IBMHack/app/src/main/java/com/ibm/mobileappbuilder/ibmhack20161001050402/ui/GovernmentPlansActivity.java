

package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;

import ibmmobileappbuilder.ui.BaseListingActivity;
/**
 * GovernmentPlansActivity list activity
 */
public class GovernmentPlansActivity extends BaseListingActivity {

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(getString(R.string.governmentPlansActivity));
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return GovernmentPlansFragment.class;
    }

}

