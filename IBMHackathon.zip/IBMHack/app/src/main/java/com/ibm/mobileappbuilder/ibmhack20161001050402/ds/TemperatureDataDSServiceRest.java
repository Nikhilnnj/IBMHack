
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface TemperatureDataDSServiceRest{

	@GET("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS")
	void queryTemperatureDataDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<TemperatureDataDSItem>> cb);

	@GET("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS/{id}")
	void getTemperatureDataDSItemById(@Path("id") String id, Callback<TemperatureDataDSItem> cb);

	@DELETE("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS/{id}")
  void deleteTemperatureDataDSItemById(@Path("id") String id, Callback<TemperatureDataDSItem> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<TemperatureDataDSItem>> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS")
  void createTemperatureDataDSItem(@Body TemperatureDataDSItem item, Callback<TemperatureDataDSItem> cb);

  @PUT("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS/{id}")
  void updateTemperatureDataDSItem(@Path("id") String id, @Body TemperatureDataDSItem item, Callback<TemperatureDataDSItem> cb);

  @GET("/app/57ef44d19d17e00300d4c370/r/temperatureDataDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

