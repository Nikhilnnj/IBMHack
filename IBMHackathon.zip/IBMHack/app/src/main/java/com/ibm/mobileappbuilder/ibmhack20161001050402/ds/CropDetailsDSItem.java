
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class CropDetailsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("crop") public String crop;
    @SerializedName("soil") public String soil;
    @SerializedName("information") public String information;
    @SerializedName("weather") public String weather;
    @SerializedName("image") public String image;
    @SerializedName("id") public String id;
    @SerializedName("imageUri") public transient Uri imageUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(crop);
        dest.writeString(soil);
        dest.writeString(information);
        dest.writeString(weather);
        dest.writeString(image);
        dest.writeString(id);
    }

    public static final Creator<CropDetailsDSItem> CREATOR = new Creator<CropDetailsDSItem>() {
        @Override
        public CropDetailsDSItem createFromParcel(Parcel in) {
            CropDetailsDSItem item = new CropDetailsDSItem();

            item.crop = in.readString();
            item.soil = in.readString();
            item.information = in.readString();
            item.weather = in.readString();
            item.image = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public CropDetailsDSItem[] newArray(int size) {
            return new CropDetailsDSItem[size];
        }
    };

}


