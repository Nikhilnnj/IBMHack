

package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.Arrays;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;

import ibmmobileappbuilder.ui.BaseFragment;
import ibmmobileappbuilder.ui.FilterActivity;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;

import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDS;
import ibmmobileappbuilder.dialogs.ValuesSelectionDialog;
import ibmmobileappbuilder.views.DateRangePicker;
import ibmmobileappbuilder.views.ListSelectionPicker;
import java.util.ArrayList;
import java.util.Date;

/**
 * CropHistoryFilterActivity filter activity
 */
public class CropHistoryFilterActivity extends FilterActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // set title
        setTitle(R.string.cropHistoryFilterActivity);
    }

    @Override
    protected Fragment getFragment() {
        return new PlaceholderFragment();
    }

    public static class PlaceholderFragment extends BaseFragment {
        private SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
        private SearchOptions searchOptions;

        // filter field values
            
    ArrayList<String> crop_values;
    
    long date_min = -1;
    long date_max = -1;

        public PlaceholderFragment() {
              searchOptions = SearchOptions.Builder.searchOptions().build();
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            return inflater.inflate(R.layout.crophistory_filter, container, false);
        }

        @Override
        public void onViewCreated(View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            // Get saved values
            Bundle bundle = savedInstanceState;
            if(bundle == null) {
                bundle = getArguments();
            }
            // get initial data
                        
            crop_values = bundle.getStringArrayList("crop_values");
            
            date_max = bundle.getLong("date_max", -1);
            date_min = bundle.getLong("date_min", -1);

            // bind pickers
                        
            final ListSelectionPicker crop_view = (ListSelectionPicker) view.findViewById(R.id.crop_filter);
            ValuesSelectionDialog crop_dialog = (ValuesSelectionDialog) getFragmentManager().findFragmentByTag("crop");
            if (crop_dialog == null)
                crop_dialog = new ValuesSelectionDialog();
            
            // configure the dialog
            crop_dialog.setColumnName("crop")
                .setDatasource(CropHistoryDS.getInstance(searchOptions))
                .setSearchOptions(searchOptions)
                .setTitle("Crop")
                .setHaveSearch(true)
                .setMultipleChoice(true);
            
            // bind the dialog to the picker
            crop_view.setSelectionDialog(crop_dialog)
                .setTag("crop")
                .setSelectedValues(crop_values)
                .setSelectedListener(new ListSelectionPicker.ListSelectedListener() {
                @Override
                public void onSelected(ArrayList<String> selected) {
                    crop_values = selected;
                }
            });
            
            final DateRangePicker date_view = (DateRangePicker) view.findViewById(R.id.date_filter);
            date_view.setMinDate(date_min != -1? new Date(date_min) : null)
                .setMaxDate(date_max != -1? new Date(date_max) : null)
                .setRangeSelectedListener(new DateRangePicker.DateRangeSelectedListener() {
                @Override
                public void onRangeSelected(Date dateMin, Date dateMax) {
                    date_min = dateMin != null ? dateMin.getTime() : -1;
                    date_max = dateMax != null ? dateMax.getTime() : -1;
                }
            });

            // Bind buttons
            Button okBtn = (Button) view.findViewById(R.id.ok);
            okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();

                    // send filter result back to caller
                                        
                    intent.putStringArrayListExtra("crop_values", crop_values);
                    
                    intent.putExtra("date_min", date_min);
                    intent.putExtra("date_max", date_max);

                    getActivity().setResult(RESULT_OK, intent);
                    getActivity().finish();
                }
            });

            Button cancelBtn = (Button) view.findViewById(R.id.reset);
            cancelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Reset values
                                        
                    crop_values = new ArrayList<String>();
                    crop_view.setSelectedValues(null);
                    
                    date_view.setMinDate(null);
                    date_min = -1;
                    date_view.setMaxDate(null);
                    date_max = -1;
                }
            });
        }

        @Override
        public void onSaveInstanceState(Bundle bundle) {
            super.onSaveInstanceState(bundle);

            // save current status
                        
            bundle.putStringArrayList("crop_values", crop_values);
            
            bundle.putLong("date_max", date_max);
            bundle.putLong("date_min", date_min);
        }
    }

}

