
package com.ibm.mobileappbuilder.ibmhack20161001050402.presenters;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class CropHistoryDetailPresenter extends BasePresenter implements DetailCrudPresenter<CropHistoryDSItem>,
      Datasource.Listener<CropHistoryDSItem> {

    private final CrudDatasource<CropHistoryDSItem> datasource;
    private final DetailView view;

    public CropHistoryDetailPresenter(CrudDatasource<CropHistoryDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(CropHistoryDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(CropHistoryDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(CropHistoryDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

