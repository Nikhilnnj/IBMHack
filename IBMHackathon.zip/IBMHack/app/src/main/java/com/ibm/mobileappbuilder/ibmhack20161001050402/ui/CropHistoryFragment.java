package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSService;
import com.ibm.mobileappbuilder.ibmhack20161001050402.presenters.CropHistoryPresenter;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.behaviors.SearchBehavior;
import ibmmobileappbuilder.behaviors.SelectionBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ui.ListGridFragment;
import ibmmobileappbuilder.util.ColorUtils;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.util.ViewHolder;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDS;
import ibmmobileappbuilder.mvp.view.CrudListView;
import ibmmobileappbuilder.ds.CrudDatasource;
import android.content.Intent;
import ibmmobileappbuilder.util.Constants;

import static ibmmobileappbuilder.util.NavigationUtils.generateIntentToAddOrUpdateItem;

/**
 * "CropHistoryFragment" listing
 */
public class CropHistoryFragment extends ListGridFragment<CropHistoryDSItem> implements CrudListView<CropHistoryDSItem> {

    private CrudDatasource<CropHistoryDSItem> datasource;

    
    ArrayList<String> crop_values;
    
    long date_min = -1;
    long date_max = -1;
    // "Add" button
    private FabBehaviour fabBehavior;

    public static CropHistoryFragment newInstance(Bundle args) {
        CropHistoryFragment fr = new CropHistoryFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPresenter(new CropHistoryPresenter(
            (CrudDatasource) getDatasource(),
            this
        ));
        addBehavior(new SearchBehavior(this));
        // Multiple selection
        SelectionBehavior<CropHistoryDSItem> selectionBehavior = new SelectionBehavior<>(
            this,
            R.string.remove_items,
            R.drawable.ic_delete_alpha);

        selectionBehavior.setCallback(new SelectionBehavior.Callback<CropHistoryDSItem>() {
            @Override
            public void onSelected(List<CropHistoryDSItem> selectedItems) {
                getPresenter().deleteItems(selectedItems);
            }
        });
        addBehavior(selectionBehavior);
        // FAB button
        fabBehavior = new FabBehaviour(this, R.drawable.ic_add_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().addForm();
            }
        });
        addBehavior(fabBehavior);
    }

    protected SearchOptions getSearchOptions() {
      SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
      return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.crophistory_item;
    }

    @Override
    protected Datasource<CropHistoryDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
      datasource = CropHistoryDS.getInstance(getSearchOptions());
      return datasource;
    }

    @Override
    protected void bindView(CropHistoryDSItem item, View view, int position) {
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        if (item.crop != null){
            title.setText(item.crop);
            
        }
        
        TextView subtitle = ViewHolder.get(view, R.id.subtitle);
        
        if (item.date != null){
            subtitle.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.date));
            
        }
    }

    @Override
    protected void itemClicked(final CropHistoryDSItem item, final int position) {
        fabBehavior.hide(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                getPresenter().detail(item, position);
            }
        });
    }

    @Override
    public void showDetail(CropHistoryDSItem item, int position) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, item);
        Intent intent = new Intent(getActivity(), CropHistoryDetailActivity.class);
        intent.putExtras(args);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

    @Override
    public void showAdd() {
        startActivityForResult(generateIntentToAddOrUpdateItem(null,
                        0,
                        getActivity(),
                        CropHistoryDSItemFormActivity.class
                ), Constants.MODE_CREATE
        );
    }

    @Override
    public void showEdit(CropHistoryDSItem item, int position) {
    startActivityForResult(
                generateIntentToAddOrUpdateItem(item,
                        position,
                        getActivity(),
                        CropHistoryDSItemFormActivity.class
                ), Constants.MODE_EDIT
        );
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        // inflate menu options and tint icon
        inflater.inflate(R.menu.filter_menu, menu);
        ColorUtils.tintIcon(menu.findItem(R.id.filter),
                            R.color.textBarColor,
                            getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.filter){
            Intent intent = new Intent(getActivity(), CropHistoryFilterActivity.class);

            // pass current values to filter activity
                        
            intent.putStringArrayListExtra("crop_values", crop_values);
            
            intent.putExtra("date_min", date_min);
            intent.putExtra("date_max", date_max);

            // launch filter screen
            startActivityForResult(intent, 1);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            // store the incoming selection
                        
            crop_values = data.getStringArrayListExtra("crop_values");
            
            date_min = data.getLongExtra("date_min", -1);
            date_max = data.getLongExtra("date_max", -1);
            // apply filter to datasource
            clearFilters();

                        
            if(crop_values != null && crop_values.size() > 0)
                addStringFilter("crop", crop_values);
            
            if(date_max != -1 || date_min != -1)
                addDateRangeFilter("date", date_min, date_max);
            // and finally refresh the list
            refresh();

            // and redraw menu (to refresh tinted icons, like the search icon)
            getActivity().invalidateOptionsMenu();
        }
    }
}

