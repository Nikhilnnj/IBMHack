
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.util.Date;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class CropHistoryDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("crop") public String crop;
    @SerializedName("inputCost") public Double inputCost;
    @SerializedName("profit") public Double profit;
    @SerializedName("date") public Date date;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(crop);
        dest.writeValue(inputCost);
        dest.writeValue(profit);
        dest.writeValue(date != null ? date.getTime() : null);
        dest.writeString(id);
    }

    public static final Creator<CropHistoryDSItem> CREATOR = new Creator<CropHistoryDSItem>() {
        @Override
        public CropHistoryDSItem createFromParcel(Parcel in) {
            CropHistoryDSItem item = new CropHistoryDSItem();

            item.crop = in.readString();
            item.inputCost = (Double) in.readValue(null);
            item.profit = (Double) in.readValue(null);
            Long dateAux = (Long) in.readValue(null);
            item.date = dateAux != null ? new Date(dateAux) : null;
            item.id = in.readString();
            return item;
        }

        @Override
        public CropHistoryDSItem[] newArray(int size) {
            return new CropHistoryDSItem[size];
        }
    };

}


