
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface CropHistoryDSServiceRest{

	@GET("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS")
	void queryCropHistoryDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<CropHistoryDSItem>> cb);

	@GET("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS/{id}")
	void getCropHistoryDSItemById(@Path("id") String id, Callback<CropHistoryDSItem> cb);

	@DELETE("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS/{id}")
  void deleteCropHistoryDSItemById(@Path("id") String id, Callback<CropHistoryDSItem> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<CropHistoryDSItem>> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS")
  void createCropHistoryDSItem(@Body CropHistoryDSItem item, Callback<CropHistoryDSItem> cb);

  @PUT("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS/{id}")
  void updateCropHistoryDSItem(@Path("id") String id, @Body CropHistoryDSItem item, Callback<CropHistoryDSItem> cb);

  @GET("/app/57ef44d19d17e00300d4c370/r/cropHistoryDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

