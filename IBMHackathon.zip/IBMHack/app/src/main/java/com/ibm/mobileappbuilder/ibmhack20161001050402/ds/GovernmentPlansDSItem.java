
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class GovernmentPlansDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("scheme") public String scheme;
    @SerializedName("launchDate") public String launchDate;
    @SerializedName("provisions") public String provisions;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(scheme);
        dest.writeString(launchDate);
        dest.writeString(provisions);
        dest.writeString(id);
    }

    public static final Creator<GovernmentPlansDSItem> CREATOR = new Creator<GovernmentPlansDSItem>() {
        @Override
        public GovernmentPlansDSItem createFromParcel(Parcel in) {
            GovernmentPlansDSItem item = new GovernmentPlansDSItem();

            item.scheme = in.readString();
            item.launchDate = in.readString();
            item.provisions = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public GovernmentPlansDSItem[] newArray(int size) {
            return new GovernmentPlansDSItem[size];
        }
    };

}


