
package com.ibm.mobileappbuilder.ibmhack20161001050402.presenters;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class CropHistoryPresenter extends BasePresenter implements ListCrudPresenter<CropHistoryDSItem>,
      Datasource.Listener<CropHistoryDSItem>{

    private final CrudDatasource<CropHistoryDSItem> crudDatasource;
    private final CrudListView<CropHistoryDSItem> view;

    public CropHistoryPresenter(CrudDatasource<CropHistoryDSItem> crudDatasource,
                                         CrudListView<CropHistoryDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(CropHistoryDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<CropHistoryDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(CropHistoryDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(CropHistoryDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(CropHistoryDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

