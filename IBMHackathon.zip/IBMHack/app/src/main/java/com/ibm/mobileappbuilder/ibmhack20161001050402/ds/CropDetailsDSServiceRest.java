
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface CropDetailsDSServiceRest{

	@GET("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS")
	void queryCropDetailsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<CropDetailsDSItem>> cb);

	@GET("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS/{id}")
	void getCropDetailsDSItemById(@Path("id") String id, Callback<CropDetailsDSItem> cb);

	@DELETE("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS/{id}")
  void deleteCropDetailsDSItemById(@Path("id") String id, Callback<CropDetailsDSItem> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<CropDetailsDSItem>> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS")
  void createCropDetailsDSItem(@Body CropDetailsDSItem item, Callback<CropDetailsDSItem> cb);

  @PUT("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS/{id}")
  void updateCropDetailsDSItem(@Path("id") String id, @Body CropDetailsDSItem item, Callback<CropDetailsDSItem> cb);

  @GET("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS")
    void createCropDetailsDSItem(
        @Part("data") CropDetailsDSItem item,
        @Part("image") TypedByteArray image,
        Callback<CropDetailsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef44d19d17e00300d4c370/r/cropDetailsDS/{id}")
    void updateCropDetailsDSItem(
        @Path("id") String id,
        @Part("data") CropDetailsDSItem item,
        @Part("image") TypedByteArray image,
        Callback<CropDetailsDSItem> cb);
}

