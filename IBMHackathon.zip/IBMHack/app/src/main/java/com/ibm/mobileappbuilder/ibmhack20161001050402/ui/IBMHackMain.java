package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import ibmmobileappbuilder.ui.DrawerActivity;

import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropDetailsDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.Item;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;

public class IBMHackMain extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
                sectionFragments.append(R.id.entry0, CropDetailsFragment.class);
            sectionFragments.append(R.id.entry1, CropHistoryFragment.class);
            sectionFragments.append(R.id.entry2, GovernmentPlansFragment.class);
            sectionFragments.append(R.id.entry3, MarketPricesFragment.class);
            sectionFragments.append(R.id.entry4, WeatherDetailsFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}

