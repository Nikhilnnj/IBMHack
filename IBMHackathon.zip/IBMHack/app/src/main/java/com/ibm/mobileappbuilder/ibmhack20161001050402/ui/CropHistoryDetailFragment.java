
package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSService;
import com.ibm.mobileappbuilder.ibmhack20161001050402.presenters.CropHistoryDetailPresenter;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.util.ColorUtils;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDS;

public class CropHistoryDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<CropHistoryDSItem> implements ShareBehavior.ShareListener  {

    private CrudDatasource<CropHistoryDSItem> datasource;
    public static CropHistoryDetailFragment newInstance(Bundle args){
        CropHistoryDetailFragment fr = new CropHistoryDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public CropHistoryDetailFragment(){
        super();
    }

    @Override
    public Datasource<CropHistoryDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CropHistoryDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        // the presenter for this view
        setPresenter(new CropHistoryDetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<CropHistoryDSItem>) getPresenter()).editForm(getItem());
            }
        }));
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.crophistorydetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final CropHistoryDSItem item, View view) {
        if (item.crop != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.crop);
            
        }
        if (item.inputCost != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(StringUtils.doubleToString(item.inputCost, true));
            
        }
        if (item.profit != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(StringUtils.doubleToString(item.profit, true));
            
        }
        if (item.date != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.date));
            
        }
    }

    @Override
    protected void onShow(CropHistoryDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Crop History");
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), CropHistoryDSItemFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            ((DetailCrudPresenter<CropHistoryDSItem>) getPresenter()).deleteItem(getItem());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onShare() {
        CropHistoryDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.crop != null ? item.crop : "" ) + "\n" +
                    (item.inputCost != null ? StringUtils.doubleToString(item.inputCost, true) : "" ) + "\n" +
                    (item.profit != null ? StringUtils.doubleToString(item.profit, true) : "" ) + "\n" +
                    (item.date != null ? DateFormat.getMediumDateFormat(getActivity()).format(item.date) : "" ));
        intent.putExtra(Intent.EXTRA_SUBJECT, "Crop History");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

