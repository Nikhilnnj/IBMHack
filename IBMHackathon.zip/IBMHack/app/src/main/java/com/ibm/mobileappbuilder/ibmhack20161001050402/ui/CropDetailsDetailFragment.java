
package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropDetailsDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropDetailsDS;

public class CropDetailsDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<CropDetailsDSItem> implements ShareBehavior.ShareListener  {

    private Datasource<CropDetailsDSItem> datasource;
    public static CropDetailsDetailFragment newInstance(Bundle args){
        CropDetailsDetailFragment fr = new CropDetailsDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public CropDetailsDetailFragment(){
        super();
    }

    @Override
    public Datasource<CropDetailsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CropDetailsDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.cropdetailsdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final CropDetailsDSItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.image);
        if(view0Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view0.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view0.setImageDrawable(null);
        }
        if (item.crop != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.crop);
            
        }
        if (item.soil != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.soil);
            
        }
        if (item.information != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText(item.information);
            
        }
        if (item.weather != null){
            
            TextView view4 = (TextView) view.findViewById(R.id.view4);
            view4.setText(item.weather);
            
        }
    }

    @Override
    protected void onShow(CropDetailsDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
    @Override
    public void onShare() {
        CropDetailsDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.crop != null ? item.crop : "" ) + "\n" +
                    (item.soil != null ? item.soil : "" ) + "\n" +
                    (item.information != null ? item.information : "" ) + "\n" +
                    (item.weather != null ? item.weather : "" ));
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

