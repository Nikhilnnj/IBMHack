
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class TemperatureDataDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("year") public String year;
    @SerializedName("annual") public String annual;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(year);
        dest.writeString(annual);
        dest.writeString(id);
    }

    public static final Creator<TemperatureDataDSItem> CREATOR = new Creator<TemperatureDataDSItem>() {
        @Override
        public TemperatureDataDSItem createFromParcel(Parcel in) {
            TemperatureDataDSItem item = new TemperatureDataDSItem();

            item.year = in.readString();
            item.annual = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public TemperatureDataDSItem[] newArray(int size) {
            return new TemperatureDataDSItem[size];
        }
    };

}


