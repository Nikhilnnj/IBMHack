
package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDSService;
import com.ibm.mobileappbuilder.ibmhack20161001050402.presenters.GovernmentPlansFormPresenter;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.GovernmentPlansDS;

public class GovernmentPlansDSItemFormFragment extends FormFragment<GovernmentPlansDSItem> {

    private CrudDatasource<GovernmentPlansDSItem> datasource;

    public static GovernmentPlansDSItemFormFragment newInstance(Bundle args){
        GovernmentPlansDSItemFormFragment fr = new GovernmentPlansDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public GovernmentPlansDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new GovernmentPlansFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected GovernmentPlansDSItem newItem() {
        return new GovernmentPlansDSItem();
    }

    private GovernmentPlansDSService getRestService(){
        return GovernmentPlansDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.governmentplans_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final GovernmentPlansDSItem item, View view) {
        
        bindString(R.id.governmentplansds_scheme, item.scheme, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.scheme = s.toString();
            }
        });
        
        
        bindString(R.id.governmentplansds_launchdate, item.launchDate, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.launchDate = s.toString();
            }
        });
        
        
        bindString(R.id.governmentplansds_provisions, item.provisions, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.provisions = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<GovernmentPlansDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = GovernmentPlansDS.getInstance(new SearchOptions());
        return datasource;
    }
}

