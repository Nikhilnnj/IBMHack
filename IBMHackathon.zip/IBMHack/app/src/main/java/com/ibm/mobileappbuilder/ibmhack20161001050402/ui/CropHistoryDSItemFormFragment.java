
package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSService;
import com.ibm.mobileappbuilder.ibmhack20161001050402.presenters.CropHistoryFormPresenter;
import com.ibm.mobileappbuilder.ibmhack20161001050402.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.DatePicker;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import java.util.Date;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDSItem;
import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropHistoryDS;

public class CropHistoryDSItemFormFragment extends FormFragment<CropHistoryDSItem> {

    private CrudDatasource<CropHistoryDSItem> datasource;

    public static CropHistoryDSItemFormFragment newInstance(Bundle args){
        CropHistoryDSItemFormFragment fr = new CropHistoryDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public CropHistoryDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new CropHistoryFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected CropHistoryDSItem newItem() {
        return new CropHistoryDSItem();
    }

    private CropHistoryDSService getRestService(){
        return CropHistoryDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.crophistory_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final CropHistoryDSItem item, View view) {
        
        bindString(R.id.crophistoryds_crop, item.crop, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.crop = s.toString();
            }
        });
        
        
        bindDouble(R.id.crophistoryds_inputcost, item.inputCost, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.inputCost = StringUtils.parseDouble(s.toString());
            }
        });
        
        
        bindDouble(R.id.crophistoryds_profit, item.profit, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.profit = StringUtils.parseDouble(s.toString());
            }
        });
        
        
        bindDatePicker(R.id.crophistoryds_date, item.date, new DatePicker.DateSelectedListener() {
            @Override
            public void onSelected(Date selected) {
                item.date = selected;
            }
        });
        
    }

    @Override
    public Datasource<CropHistoryDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CropHistoryDS.getInstance(new SearchOptions());
        return datasource;
    }
}

