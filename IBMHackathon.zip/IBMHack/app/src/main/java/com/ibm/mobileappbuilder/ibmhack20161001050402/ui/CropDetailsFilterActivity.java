

package com.ibm.mobileappbuilder.ibmhack20161001050402.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.Arrays;

import com.ibm.mobileappbuilder.ibmhack20161001050402.R;

import ibmmobileappbuilder.ui.BaseFragment;
import ibmmobileappbuilder.ui.FilterActivity;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;

import com.ibm.mobileappbuilder.ibmhack20161001050402.ds.CropDetailsDS;
import ibmmobileappbuilder.dialogs.ValuesSelectionDialog;
import ibmmobileappbuilder.views.ListSelectionPicker;
import java.util.ArrayList;

/**
 * CropDetailsFilterActivity filter activity
 */
public class CropDetailsFilterActivity extends FilterActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // set title
        setTitle(R.string.cropDetailsFilterActivity);
    }

    @Override
    protected Fragment getFragment() {
        return new PlaceholderFragment();
    }

    public static class PlaceholderFragment extends BaseFragment {
        private SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
        private SearchOptions searchOptions;

        // filter field values
            
    ArrayList<String> crop_values;
    
    ArrayList<String> soil_values;

        public PlaceholderFragment() {
              searchOptions = SearchOptions.Builder.searchOptions().build();
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            return inflater.inflate(R.layout.cropdetails_filter, container, false);
        }

        @Override
        public void onViewCreated(View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            // Get saved values
            Bundle bundle = savedInstanceState;
            if(bundle == null) {
                bundle = getArguments();
            }
            // get initial data
                        
            crop_values = bundle.getStringArrayList("crop_values");
            
            soil_values = bundle.getStringArrayList("soil_values");

            // bind pickers
                        
            final ListSelectionPicker crop_view = (ListSelectionPicker) view.findViewById(R.id.crop_filter);
            ValuesSelectionDialog crop_dialog = (ValuesSelectionDialog) getFragmentManager().findFragmentByTag("crop");
            if (crop_dialog == null)
                crop_dialog = new ValuesSelectionDialog();
            
            // configure the dialog
            crop_dialog.setColumnName("crop")
                .setDatasource(CropDetailsDS.getInstance(searchOptions))
                .setSearchOptions(searchOptions)
                .setTitle("Crop")
                .setHaveSearch(true)
                .setMultipleChoice(true);
            
            // bind the dialog to the picker
            crop_view.setSelectionDialog(crop_dialog)
                .setTag("crop")
                .setSelectedValues(crop_values)
                .setSelectedListener(new ListSelectionPicker.ListSelectedListener() {
                @Override
                public void onSelected(ArrayList<String> selected) {
                    crop_values = selected;
                }
            });
            
            final ListSelectionPicker soil_view = (ListSelectionPicker) view.findViewById(R.id.soil_filter);
            ValuesSelectionDialog soil_dialog = (ValuesSelectionDialog) getFragmentManager().findFragmentByTag("soil");
            if (soil_dialog == null)
                soil_dialog = new ValuesSelectionDialog();
            
            // configure the dialog
            soil_dialog.setColumnName("soil")
                .setDatasource(CropDetailsDS.getInstance(searchOptions))
                .setSearchOptions(searchOptions)
                .setTitle("Soil")
                .setHaveSearch(true)
                .setMultipleChoice(true);
            
            // bind the dialog to the picker
            soil_view.setSelectionDialog(soil_dialog)
                .setTag("soil")
                .setSelectedValues(soil_values)
                .setSelectedListener(new ListSelectionPicker.ListSelectedListener() {
                @Override
                public void onSelected(ArrayList<String> selected) {
                    soil_values = selected;
                }
            });

            // Bind buttons
            Button okBtn = (Button) view.findViewById(R.id.ok);
            okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();

                    // send filter result back to caller
                                        
                    intent.putStringArrayListExtra("crop_values", crop_values);
                    
                    intent.putStringArrayListExtra("soil_values", soil_values);

                    getActivity().setResult(RESULT_OK, intent);
                    getActivity().finish();
                }
            });

            Button cancelBtn = (Button) view.findViewById(R.id.reset);
            cancelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Reset values
                                        
                    crop_values = new ArrayList<String>();
                    crop_view.setSelectedValues(null);
                    
                    soil_values = new ArrayList<String>();
                    soil_view.setSelectedValues(null);
                }
            });
        }

        @Override
        public void onSaveInstanceState(Bundle bundle) {
            super.onSaveInstanceState(bundle);

            // save current status
                        
            bundle.putStringArrayList("crop_values", crop_values);
            
            bundle.putStringArrayList("soil_values", soil_values);
        }
    }

}

