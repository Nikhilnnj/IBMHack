
package com.ibm.mobileappbuilder.ibmhack20161001050402.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface GovernmentPlansDSServiceRest{

	@GET("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS")
	void queryGovernmentPlansDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<GovernmentPlansDSItem>> cb);

	@GET("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS/{id}")
	void getGovernmentPlansDSItemById(@Path("id") String id, Callback<GovernmentPlansDSItem> cb);

	@DELETE("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS/{id}")
  void deleteGovernmentPlansDSItemById(@Path("id") String id, Callback<GovernmentPlansDSItem> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<GovernmentPlansDSItem>> cb);

  @POST("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS")
  void createGovernmentPlansDSItem(@Body GovernmentPlansDSItem item, Callback<GovernmentPlansDSItem> cb);

  @PUT("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS/{id}")
  void updateGovernmentPlansDSItem(@Path("id") String id, @Body GovernmentPlansDSItem item, Callback<GovernmentPlansDSItem> cb);

  @GET("/app/57ef44d19d17e00300d4c370/r/governmentPlansDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

